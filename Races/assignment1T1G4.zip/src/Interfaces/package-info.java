/**
 * Conjunto de interfaces.
 */
package Interfaces;

