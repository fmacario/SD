package Interfaces;

/**
 *
 * @author fm
 */
public interface IPaddock_Spectator {

    /**
     *
     * @param spectatorID
     */
    void goCheckHorses( int spectatorID );

    /**
     *
     * @param spectatorID
     */
    void waitForNextRace( int spectatorID );
}
