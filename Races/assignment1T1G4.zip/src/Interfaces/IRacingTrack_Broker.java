package Interfaces;

import java.util.ArrayList;

/**
 *
 * @author fm
 */
public interface IRacingTrack_Broker {

    /**
     *
     * @return
     */
    ArrayList<Integer> startTheRace();
}
