/**
 * Conjunto de monitores (regiões partilhadas).
 */
package Monitores;

