/**
 * Conjunto de threads (intervenientes).
 */
package Threads;

