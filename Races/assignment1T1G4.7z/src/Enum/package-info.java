/**
 * Conjunto de enumerados que definem os estados dos intervenientes.
 */
package Enum;
