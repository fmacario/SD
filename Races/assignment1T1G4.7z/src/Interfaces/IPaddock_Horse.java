package Interfaces;

/**
 *
 * @author fm
 */
public interface IPaddock_Horse {

    /**
     *
     * @param horseID
     */
    void proceedToPaddock( int horseID);
}
