package Interfaces;

/**
 *
 * @author fm
 */
public interface IStable_Horse {

    /**
     *
     * @param horseID
     * @param agile
     */
    void proceedToStable(int horseID , int agile);
}
